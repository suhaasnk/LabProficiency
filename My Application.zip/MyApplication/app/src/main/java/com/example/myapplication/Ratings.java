package com.example.myapplication;

public class Ratings {
    public int upvotes;

    public Ratings() {}
}
